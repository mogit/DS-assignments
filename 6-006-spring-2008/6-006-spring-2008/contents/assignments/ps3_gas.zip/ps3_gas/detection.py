def detect_collisions(balls):
    """ 
    Detect any pairs of balls that are colliding.
    Returns a set of ball_pairs.
    """

    set_of_collisions = set()

    for i in range(len(balls)):
        b1 = balls[i]
        for j in range(i):
            b2 = balls[j]
            if gas.colliding(b1, b2):
                set_of_collisions.add(gas.ball_pair(b1, b2))

    return set_of_collisions

import gas
