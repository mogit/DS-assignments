from heap import *

class heap_delete(heap):
    def delete(self, i):
        return None

