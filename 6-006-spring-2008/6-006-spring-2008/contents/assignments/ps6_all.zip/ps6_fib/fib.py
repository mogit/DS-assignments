#!/usr/bin/python

def fib_recursive(n):
    return 'NOT_IMPLEMENTED'

def fib_memoize(n):
    return 'NOT_IMPLEMENTED'

def fib_bottom_up(n):
    return 'NOT_IMPLEMENTED'

def fib_in_place(n):
    return 'NOT_IMPLEMENTED'
