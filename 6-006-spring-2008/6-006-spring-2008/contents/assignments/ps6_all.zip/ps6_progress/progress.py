#!/usr/bin/python

def longest_increasing_subsequence(scores):
    return 'NOT_IMPLEMENTED'
