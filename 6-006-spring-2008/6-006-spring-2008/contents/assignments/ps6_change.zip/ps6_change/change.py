#!/usr/bin/python

def make_change(denominations, C):
    return 'NOT_IMPLEMENTED'
