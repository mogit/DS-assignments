srand 122983
[21, 41, 61, 81, 101, 301].each do |size|
  File.open("parens_#{size-1}", 'w') do |f|
    f.write "#{size}\n"
    size.times { f.write "#{1 + rand(500)}\n" }
  end
end
