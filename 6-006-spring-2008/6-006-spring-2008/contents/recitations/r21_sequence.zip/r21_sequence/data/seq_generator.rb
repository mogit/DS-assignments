srand 122983
[100, 500, 1000, 5000].each do |size|
  File.open("seq_#{size}", 'w') do |f|
    f.write "#{size}\n"
    size.times { f.write "#{rand size * 5}\n" }
  end
end
