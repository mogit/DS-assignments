def solve(array):
    """find a longest zig-zag sequence in the given array, return its indices"""
    return []
