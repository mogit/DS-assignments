def solve(array):
    """find a longest zig-zag sequence in the given array, return its indices"""
    smax = [[0, 0] for i in range(len(array))]
    pi = [[None, None] for i in range(len(array))]
    
    for i in range(len(array)):
        for j in range(i):
            if array[j] < array[i]: # zig
                zig_zag = 0
            elif array[j] > array[i]: # zag
                zig_zag = 1
            else:
                continue
            if smax[i][1 - zig_zag] < smax[j][zig_zag]:
                smax[i][1 - zig_zag] = smax[j][zig_zag]
                pi[i][1 - zig_zag] = j
        for zig_zag in [0, 1]:
            smax[i][zig_zag] += 1
    
    max_s, max_i, max_zig_zag = 0, None, None
    for i in range(len(array)):
        for zig_zag in [0, 1]:
            if max_s < smax[i][zig_zag]:
                max_s = smax[i][zig_zag]
                max_i = i
                max_zig_zag = zig_zag
    
    solution = []
    while max_i is not None:
        solution.append(max_i)
        max_i = pi[max_i][max_zig_zag]
        max_zig_zag = 1 - max_zig_zag
    solution.reverse()
    return solution
